export class UpdateSitfoundationDto {}
