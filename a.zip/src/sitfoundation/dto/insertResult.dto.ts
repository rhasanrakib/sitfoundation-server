export class InsertResultDto {
  readonly regNumber: string;
}
